const $ = (id) => document.getElementById(id);

$("menuToggle").addEventListener("click", () => $("mainNav").classList.toggle("open"));
document.querySelectorAll("#mainNav a").forEach(a => a.addEventListener("click", () => $("mainNav").classList.remove("open")));

let breathing = false, breathTimer;
$("breathButton").addEventListener("click", () => {
  if (breathing) {
    clearTimeout(breathTimer); breathing = false;
    $("breathText").textContent = "Ready?"; $("breathHint").textContent = "Press start and follow the gentle breathing prompts.";
    $("breathCircle").classList.remove("expand"); $("breathButton").textContent = "Start breathing exercise"; return;
  }
  breathing = true; $("breathButton").textContent = "Stop exercise";
  const steps = [{t:"Breathe in",h:"Gently breathe in for 4 seconds.",d:4000,e:true},{t:"Breathe out",h:"Slowly breathe out for 6 seconds.",d:6000,e:false}];
  let i=0, cycles=0;
  const run = () => {
    if (!breathing) return;
    const s=steps[i]; $("breathText").textContent=s.t; $("breathHint").textContent=s.h;
    $("breathCircle").classList.toggle("expand",s.e);
    i=(i+1)%2; if(i===0) cycles++;
    if(cycles>=5){breathing=false;$("breathText").textContent="Well done";$("breathHint").textContent="Take a moment and notice how you feel.";$("breathButton").textContent="Start again";$("breathCircle").classList.remove("expand");return;}
    breathTimer=setTimeout(run,s.d);
  }; run();
});

$("budgetButton").addEventListener("click", () => {
  const income = Math.max(0, Number($("income").value)||0);
  const needs = Math.max(0, Number($("needs").value)||0);
  const study = Math.max(0, Number($("study").value)||0);
  const other = Math.max(0, Number($("other").value)||0);
  if (!income) { $("budgetMessage").textContent="Please enter the money available this month."; return; }
  const spent=needs+study+other, left=income-spent;
  $("remaining").textContent=(left<0?"−":"")+Math.abs(left).toLocaleString(undefined,{maximumFractionDigits:2});
  $("budgetMessage").textContent=left>=0?"This is your estimated amount remaining. Consider setting some aside for unexpected costs.":"Your planned spending is higher than your available money. Review flexible costs and seek support if needed.";
  $("budgetBar").style.width=Math.min(100,(spent/income)*100)+"%";
});

$("studyButton").addEventListener("click", () => {
  const subject=$("subject").value.trim(), mins=Number($("minutes").value);
  if(!subject){$("sessionOutput").textContent="Enter a subject or topic to create your session.";return;}
  const breakMins=mins>=50?10:5;
  $("sessionOutput").innerHTML=`<strong>${escapeHTML(subject)}</strong><br>1. Spend ${mins} minutes studying actively.<br>2. Take a ${breakMins}-minute break.<br>3. Close your notes and write down three things you remember.<br>4. Mark one question to ask or review.`;
});
function escapeHTML(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}

const saved=localStorage.getItem("thutospace-priorities");
if(saved) $("priorities").value=saved;
$("savePriorities").addEventListener("click",()=>{
  localStorage.setItem("thutospace-priorities",$("priorities").value);
  $("saveStatus").textContent="Saved on this device.";
});
