# ThutoSpace — Student Support Hub

A responsive, beginner-friendly student support website built with HTML, CSS and vanilla JavaScript.

## Features
- Student wellbeing tips and a guided breathing exercise.
- Simple monthly budget calculator.
- Exam preparation session builder.
- Daily priorities list saved in the visitor's browser.
- Responsive layout for phones, tablets and desktops.

## Run locally
1. Download or clone this repository.
2. Open `index.html` in a web browser.

No build tools or backend are required.

## Deploy with GitHub Pages
1. Create a new public GitHub repository (for example, `thutospace`).
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.
6. Wait for GitHub Pages to publish the site. Your address will look like:
   `https://YOUR-USERNAME.github.io/thutospace/`

## Important notes
- This is an educational support tool, not a replacement for counselling, medical care or qualified financial advice.
- Budget entries and the priorities list are stored locally in the visitor's browser. No information is sent to a server.
- Add locally verified student support and emergency contacts before promoting this site to students.
- The Google Fonts import requires an internet connection; the page remains usable with fallback fonts.
